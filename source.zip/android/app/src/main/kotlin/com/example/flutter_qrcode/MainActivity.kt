package com.example.flutter_qrcode

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
